'use client'

import React, {useEffect, useRef} from 'react'

const {WebsocketClient, WsMessageKlineRaw, MainClient} = require('binance');
import {CandlestickSeries, createChart, IChartApi, ISeriesApi, UTCTimestamp} from 'lightweight-charts'

export default function CryptoChart({ticker = 'BTCUSDT'}) {
    const containerRef = useRef<HTMLDivElement | null>(null);
    const chartRef = useRef<IChartApi | null>(null);
    const seriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);

    async function fetchCandles() {
        const restClient = new MainClient();
        const endTime = Date.now();
        const startTime = endTime - 60 * 1000 * 1000; // Minus 1000 mins
        const baseKlines = await restClient.getUIKlines({
            symbol: ticker,
            interval: "1m",
            startTime,
            endTime,
            limit: 1000
        });

        const formattedData = baseKlines.map(kline => ({
            time: Math.floor(kline[0] / 1000) as UTCTimestamp, // openTime (sec)
            open: parseFloat(kline[1]),
            high: parseFloat(kline[2]),
            low: parseFloat(kline[3]),
            close: parseFloat(kline[4]),
        }));

        seriesRef.current?.setData(formattedData);
    }

    fetchCandles();

    useEffect(() => {
        if (!containerRef.current) return;

        const isDarkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;

        chartRef.current = createChart(containerRef.current!, {
            width: containerRef.current.clientWidth,
            height: 400,
            layout: {
                background: {color: isDarkMode ? '#000' : '#FFF'},
                textColor: isDarkMode ? '#DDD' : '#222',
            },
            grid: {
                vertLines: {color: isDarkMode ? '#333' : '#EEE'},
                horzLines: {color: isDarkMode ? '#333' : '#EEE'},
            },
            timeScale: {
                timeVisible: true,
            },
        });

        seriesRef.current = chartRef.current.addSeries(CandlestickSeries);

        return () => {
            chartRef.current?.remove();
        };
    }, []);


    const wsClient = new WebsocketClient()

    wsClient.on('message', (data: typeof WsMessageKlineRaw) => {
        if (!seriesRef.current) return;

        seriesRef.current.update({
            time: Math.floor(data.k.t) as UTCTimestamp,
            open: parseFloat(data.k.o),
            high: parseFloat(data.k.h),
            low: parseFloat(data.k.l),
            close: parseFloat(data.k.c),
        });
    })

    wsClient.subscribeKlines(ticker, '1m', 'spot');

    return <div ref={containerRef} style={{width: 'auto', height: '400px'}}/>;
}