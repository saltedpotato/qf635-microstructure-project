'use client';

import {useEffect, useState} from 'react';
import {motion, AnimatePresence} from 'framer-motion';
import CryptoChart from './components/CryptoChart';

const TICKERS = ['BTCUSDT', 'BNBUSDT', 'ETHUSDT'];

function AnimatedNumber({
                            value,
                            digits = 2,
                            className = '',
                        }: {
    value: number | undefined;
    digits?: number;
    className?: string;
}) {
    const formatted = (value ?? 0).toLocaleString(undefined, {
        maximumFractionDigits: digits,
    });

    return (
        <AnimatePresence mode="popLayout">
            <motion.span
                key={formatted}
                initial={{y: 8, opacity: 0}}
                animate={{y: 0, opacity: 1}}
                exit={{y: -8, opacity: 0}}
                transition={{duration: 0.25}}
                className={className}
            >
                {formatted}
            </motion.span>
        </AnimatePresence>
    );
}

export default function Main() {
    const [signals, setSignals] = useState<any[]>([]);
    const [summary, setSummary] = useState<any>({});
    const [loading, setLoading] = useState(true);
    const [activeTicker, setActiveTicker] = useState('BTCUSDT');

    useEffect(() => {
        let mounted = true;
        const fetchData = async () => {
            try {
                const res = await fetch('http://localhost:8888/signals');
                const json = await res.json();
                if (!mounted) return;
                setSignals(
                    (json.signals || []).sort(
                        (a: any, b: any) => TICKERS.indexOf(a.ticker) - TICKERS.indexOf(b.ticker),
                    ),
                );
                setSummary(json.summary || {});
                setLoading(false);
            } catch (err) {
                console.error('Failed to fetch signals', err);
            }
        };
        fetchData();
        const id = setInterval(fetchData, 5000);
        return () => {
            mounted = false;
            clearInterval(id);
        };
    }, []);

    const activeSignal = signals.find((s) => s.ticker === activeTicker);
    const pillBase =
        'flex items-center gap-1 text-xs font-medium px-3 py-1 rounded-md transition-colors';

    const CardShell = ({
                           children,
                           className = '',
                       }: {
        children: React.ReactNode;
        className?: string;
    }) => (
        <div
            className={`rounded-xl border border-gray-700/60 backdrop-blur-sm bg-gray-800/40 shadow-lg p-6 ${className}`}
        >
            {children}
        </div>
    );

    function TickerPill({tkr}: { tkr: string }) {
        const sig = signals.find((s) => s.ticker === tkr);
        const active = activeTicker === tkr;
        return (
            <button
                onClick={() => setActiveTicker(tkr)}
                className={`${pillBase} ${
                    active ? 'bg-indigo-500' : 'bg-gray-800 text-gray-200 hover:bg-gray-700'
                }`}
            >
        <span
            className={`inline-block w-2 h-2 rounded-full ${
                sig?.signal === 'BUY'
                    ? 'bg-green-400'
                    : sig?.signal === 'SELL'
                        ? 'bg-red-400'
                        : 'bg-gray-400'
            }`}
        />
                {tkr.replace('USDT', '')}
            </button>
        );
    }

    function PortfolioCard({sum}: { sum: any }) {
        if (!sum || Object.keys(sum).length === 0) return null;
        return (
            <CardShell className="flex-[2] min-w-[300px]">
                <h2 className="text-2xl font-bold mb-4">Portfolio</h2>
                <dl className="text-base space-y-3">
                    {[
                        ['Value', sum.portfolio_value],
                        ['Capital', sum.capital],
                    ].map(([label, val]) => {
                        const isPnl = label.includes('PnL');
                        const cls =
                            isPnl && (val ?? 0) !== 0
                                ? (val ?? 0) > 0
                                    ? 'text-green-400'
                                    : 'text-red-400'
                                : 'text-gray-100';
                        return (
                            <div
                                key={label}
                                className="flex justify-between items-baseline"
                            >
                                <dt className="text-gray-400">{label}</dt>
                                <dd className={`font-semibold text-2xl ${cls}`}>
                                    <AnimatedNumber value={val as number}/>
                                </dd>
                            </div>
                        );
                    })}
                </dl>
            </CardShell>
        );
    }

    function PnLCard({sum}: { sum: any }) {
        if (!sum || Object.keys(sum).length === 0) return null;
        return (
            <CardShell className="flex-[1] min-w-[240px]">
                <h2 className="text-2xl font-bold mb-4">Profit & Loss</h2>
                <dl className="text-base space-y-3">
                    {[
                        ['Realised PnL', sum.realised_pnl],
                        ['Unrealised PnL', sum.unrealised_pnl],
                    ].map(([label, val]) => {
                        const isPnl = label.includes('PnL');
                        const cls =
                            isPnl && (val ?? 0) !== 0
                                ? (val ?? 0) > 0
                                    ? 'text-green-400'
                                    : 'text-red-400'
                                : 'text-gray-100';
                        return (
                            <div
                                key={label}
                                className="flex justify-between items-baseline"
                            >
                                <dt className="text-gray-400">{label}</dt>
                                <dd className={`font-semibold text-2xl ${cls}`}>
                                    <AnimatedNumber value={val as number}/>
                                </dd>
                            </div>
                        );
                    })}
                </dl>
            </CardShell>
        );
    }

    function HeroCard({sig}: { sig: any }) {
        if (!sig) return null;
        const isExit = sig.exit_signals === 1;
        return (
            <CardShell className="flex-1 w-full max-w-xs">
                <div className="flex items-center gap-2">
                    <h2 className="text-xl font-bold text-gray-100">{sig.ticker.replace('USDT', '')}</h2>
                    <span
                        className={`px-2 py-0.5 text-xs rounded-full ${
                            sig.signal === 'BUY'
                                ? 'bg-green-600/80'
                                : sig.signal === 'SELL'
                                    ? 'bg-red-600/80'
                                    : 'bg-gray-600/60'
                        } text-white`}
                    >
            {sig.signal}
          </span>
                    {isExit && <span className="px-2 py-0.5 text-xs rounded-full bg-red-700 text-white">EXIT</span>}
                </div>
                <dl className="space-y-1 mt-3">
                    <div className={`font-semibold text-lg ${
                        sig.signal === 'HOLD'
                            ? 'text-green-600/80'
                            : sig.signal === 'SELL'
                                ? 'text-red-600/80'
                                : 'text-gray-600/60'
                    }`}
                    >
                        {sig.signal} {sig.qty + " @ $" + sig.qty_price}
                    </div>
                    <div className="flex justify-between items-baseline">
                        <dt className="text-gray-400">Price</dt>
                        <dd className="font-semibold text-2xl">
                            <AnimatedNumber value={sig.price} digits={4}/>
                        </dd>
                    </div>

                    <div className="flex justify-between items-baseline">
                        <dt className="text-gray-400">Position</dt>
                        <dd className="font-semibold text-2xl">
                            <AnimatedNumber value={sig.qty} digits={4}/>
                        </dd>
                    </div>
                </dl>
            </CardShell>
        );
    }

    return (
        <div className="container mx-auto p-4 space-y-6">
            <h1 className="text-3xl font-extrabold bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
                Crypto Dashboard
            </h1>

            {loading ? (
                <div className="flex items-center gap-2 text-gray-400 py-6">Loading…</div>
            ) : (
                <div className="flex flex-wrap gap-4 mb-6 items-stretch">
                    <PortfolioCard sum={summary}/>
                    <PnLCard sum={summary}/>

                    {signals.map((sig) => (
                        <HeroCard key={sig.ticker} sig={sig}/>
                    ))}
                </div>
            )}

            <div className="flex gap-2 mb-4 flex-wrap justify-center">
                {TICKERS.map((t) => (
                    <TickerPill key={t} tkr={t}/>
                ))}
            </div>

            <CardShell className="p-0 overflow-hidden">
                <CryptoChart ticker={activeTicker}/>
            </CardShell>

            <CardShell
                className="mt-6 just bg-gray-900/60 text-gray-400 overflow-auto font-mono whitespace-pre-wrap leading-5 max-h-60">
                {loading
                    ? 'Loading logs…'
                    : (() => {
                        const hdr = '====== LIVE TRADING VIEW ======';
                        const f = (n: number | undefined, digits = 2) =>
                            (n ?? 0).toLocaleString(undefined, {maximumFractionDigits: digits});
                        const line = (t: {
                            ticker: string;
                            signal: 'BUY' | 'SELL' | 'HOLD';
                            exit_signal: number;          // 0 | 1
                            price: number;
                            current_position: number;
                            qty: number;
                        }) => {
                            const price = f(t.price);
                            const position = f(t.current_position);
                            const qtyStr = f(t.qty);

                            // EXIT overrides everything else
                            if (t.exit_signal === 1) {
                                return `${t.ticker} SIGNAL: EXIT ${qtyStr} Qty @ ${price} | Current Position: ${position}\n`;
                            }

                            // BUY / SELL include trade size
                            if (t.signal === 'BUY' || t.signal === 'SELL') {
                                return `${t.ticker} SIGNAL: ${t.signal} ${qtyStr} Qty @ ${price} | Current Position: ${position}\n`;
                            }

                            // HOLD (default) – no qty shown
                            return `${t.ticker} SIGNAL: HOLD @ ${price} | Current Position: ${position}\n`;
                        };
                        const body = [
                            `Portfolio Value : $${f(summary.portfolio_value)}\n`,
                            `Realised PnL    : $${f(summary.realised_pnl)}\n`,
                            `Unrealised PnL  : $${f(summary.unrealised_pnl)}\n`,
                            `Capital         : $${f(summary.capital)}\n`,
                            ...signals.map(line),
                        ].join('');

                        return `${hdr}\n${body}==============================`;
                    })()}
            </CardShell>
        </div>
    );
}
